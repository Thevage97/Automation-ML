package pages.elements;

public class EMercado {

    public String opt_Mexico = "//*[@id=\"MX\"]";
    public String buscador = "/html/body/header/div/div[2]/form/input";
    public String poppup_Mas_tarde = "/html/body/div[5]/div/div/div[2]/div/div/div[2]/button[2]/span";
    public String filtro_Nuevo = "/html/body/main/div/div[2]/aside/section[2]/div[5]/ul/li[1]/a";
    public String filtro_cdmx = "/html/body/main/div/div[2]/aside/section[2]/div[13]/ul/li[1]";
    public String btnorderby = "/html/body/main/div/div[2]/section/div[2]/div[2]/div/div/div[2]/div/div/button";
    public String opt_mayorPrecio = "/html/body/main/div/div[2]/section/div[2]/div[2]/div/div/div[2]/div/div/div/div/div/ul/li[3]/div/div";
    public String product_one = "/html/body/main/div/div[2]/section/ol/li[1]/div/div/div[2]/h3/a";
    public String product_two = "/html/body/main/div/div[2]/section/ol/li[2]/div/div/div[2]/h3/a";
    public String product_three = "/html/body/main/div/div[2]/section/ol/li[3]/div/div/div[2]/h3/a";
    public String product_four = "/html/body/main/div/div[2]/section/ol/li[4]/div/div/div[2]/h3/a";
    public String product_five = "/html/body/main/div/div[2]/section/ol/li[5]/div/div/div[2]/h3/a";
}
