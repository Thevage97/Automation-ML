package pages;
 
import java.security.Key;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import pages.elements.EMercado;

public class MercadoLibrePages extends BasePage {

    EMercado eml = new EMercado();

    public MercadoLibrePages(){
 
        super(driver);
    }

    public void scrollToSelector(String selector){
        WebElement targetElement = driver.findElement(By.xpath(selector));
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].scrollIntoView();", targetElement);
    }

    public void tiempo(int s){
        try {
            Thread.sleep(s*1000);
        } catch (InterruptedException e) {
            
        }
    }

    public void Enter_the_website(){
        navigateTo("https://www.mercadolibre.com/");
    }

    public void Select_Mexico_as_a_country(){
        driver.findElement(By.xpath(eml.opt_Mexico)).click();
        tiempo(2);
        driver.findElement(By.xpath(eml.poppup_Mas_tarde)).click();

    }

    public void Search_for_the_term_playstation(){
        WebElement buscadorPlay = driver.findElement(By.xpath(eml.buscador));
        buscadorPlay.sendKeys("playstation 5",Keys.ENTER);
        tiempo(3);
    }

    public void Filter_by_condition_Nuevos(){
        scrollToSelector(eml.filtro_Nuevo);
        driver.findElement(By.xpath(eml.filtro_Nuevo)).click();
        tiempo(3);
    }

    public void Filter_by_location_Cdmx(){
        scrollToSelector(eml.filtro_cdmx);
        driver.findElement(By.xpath(eml.filtro_cdmx)).click();
        tiempo(3);
    }

    public void Order_by_mayor_a_menor_precio(){
        clickElement(eml.btnorderby);
        tiempo(3);
        clickElement(eml.opt_mayorPrecio);
    }

    public void Obtain_the_name_and_the_price_of_the_first_products(){
        System.out.println(driver.findElement(By.xpath(eml.product_one)).getText());
        System.out.println(driver.findElement(By.xpath(eml.product_one)).getText());
        System.out.println(driver.findElement(By.xpath(eml.product_one)).getText());
        System.out.println(driver.findElement(By.xpath(eml.product_one)).getText());
        System.out.println(driver.findElement(By.xpath(eml.product_one)).getText());
        System.out.println(driver.findElement(By.xpath(eml.product_one)).getText());
        

    }
}