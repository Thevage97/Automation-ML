package steps;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import pages.MercadoLibrePages;

public class MercadoLibre {

    MercadoLibrePages mlp = new MercadoLibrePages();

    @Given("Enter the website")
    public void Enter_the_website(){
        mlp.Enter_the_website();
    }
    
    @Then("Select Mexico as a country")
    public void Select_Mexico_as_a_country() {
        mlp.Select_Mexico_as_a_country();
    }

    @Then("Search for the term playstation 5")
    public void Search_for_the_term_playstation( ) {
        mlp.Search_for_the_term_playstation();
    }

    @Then("Filter by condition Nuevos")
    public void Filter_by_condition_Nuevos() {
        mlp.Filter_by_condition_Nuevos();
    }

    @Then("Filter by location Cdmx")
    public void Filter_by_location_Cdmx() {
        mlp.Filter_by_location_Cdmx();
    }

    @Then("Order by mayor a menor precio")
    public void Order_by_mayor_a_menor_precio() {
        mlp.Order_by_mayor_a_menor_precio();
    }

    @Then("Obtain the name and the price of the first 5 products")
    public void Obtain_the_name_and_the_price_of_the_first_products() {
        mlp.Obtain_the_name_and_the_price_of_the_first_products();
    }
}
